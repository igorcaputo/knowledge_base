<?php
/**************************************************************************/
/* AppServ Language: The Future of the Web                                */
/**************************************************************************/
define("_CHARSET","utf-8");
define("_ABOUT","About");
define("_FOR","for");
define("_IS","is a merging open source software installer package for Windows includes :");
define("_APACHE","Apache Web Server");
define("_MYSQL","MySQL Database");
define("_PERL","Perl");
define("_PHP","PHP Script Language");
define("_PHPINFO","PHP Information");
define("_ZENDOPT","Zend Optimizer");
define("_PHPMYADMIN","phpMyAdmin Database Manager");
define("_PHPNUKE","PHP-Nuke Web Portal System");
define("_PHPBB","phpBB Forum");
define("_VERSION","Version");
define("_CHANGELOG","ChangeLog");
define("_README","README");
define("_AUTHOR","AUTHORS");
define("_COPYING","COPYING");
define("_SITE","Project page");
define("_LANG","Change Language");
define("_SLOGAN","Easy way to build Webserver, Database Server with AppServ :-)");
define("_OS","Windows");
define("_OFSITE","Official Site");
define("_HSUP","Hosting support by");
?>